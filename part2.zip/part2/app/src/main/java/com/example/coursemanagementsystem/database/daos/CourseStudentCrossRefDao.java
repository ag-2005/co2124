package com.example.coursemanagementsystem.database.daos;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.coursemanagementsystem.database.entities.CourseStudentCrossRef;

import java.util.List;

/**
 * Data Access Object (DAO) for managing the many-to-many relationship
 * between courses and students using the CourseStudentCrossRef entity.
 * Provides methods to insert, delete, and query course-student links.
 */
@Dao
public interface CourseStudentCrossRefDao {

    // Insert a new course-student relationship
    @Insert
    void insert(CourseStudentCrossRef crossRef);

    // Delete a specific course-student relationship
    @Delete
    void delete(CourseStudentCrossRef crossRef);

    // Remove all student links from a specific course
    @Query("DELETE FROM coursestudentcrossref WHERE courseId = :courseId")
    void deleteAllStudentsForCourse(int courseId);

    // Remove all course links from a specific student
    @Query("DELETE FROM coursestudentcrossref WHERE studentId = :studentId")
    void deleteAllCoursesForStudent(int studentId);

    // Get all student relationships for a course
    @Query("SELECT * FROM coursestudentcrossref WHERE courseId = :courseId")
    List<CourseStudentCrossRef> getStudentsForCourse(int courseId);

    // Get all course relationships for a student
    @Query("SELECT * FROM coursestudentcrossref WHERE studentId = :studentId")
    List<CourseStudentCrossRef> getCoursesForStudent(int studentId);

    // Remove a specific student from a specific course
    @Query("DELETE FROM coursestudentcrossref WHERE courseId = :courseId AND studentId = :studentId")
    void deleteStudentFromCourse(int courseId, int studentId);

    // Check if a student is already enrolled in a specific course
    @Query("SELECT COUNT(*) FROM coursestudentcrossref WHERE courseId = :courseId AND studentId = :studentId")
    int isStudentEnrolled(int courseId, int studentId);

}
