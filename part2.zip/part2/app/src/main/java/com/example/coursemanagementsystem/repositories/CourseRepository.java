package com.example.coursemanagementsystem.repositories;

import android.app.Application;
import androidx.lifecycle.LiveData;

import com.example.coursemanagementsystem.database.AppDatabase;
import com.example.coursemanagementsystem.database.daos.CourseDao;
import com.example.coursemanagementsystem.database.daos.CourseStudentCrossRefDao;
import com.example.coursemanagementsystem.database.daos.StudentDao;
import com.example.coursemanagementsystem.database.entities.Course;
import com.example.coursemanagementsystem.database.entities.CourseStudentCrossRef;

import java.util.ArrayList;
import java.util.List;

/**
 * Repository class that handles data operations for courses.
 * Connects the ViewModel to the Room database and abstracts logic.
 */
public class CourseRepository {

    // DAOs
    private final CourseDao courseDao;
    private final CourseStudentCrossRefDao crossRefDao;
    private final StudentDao studentDao;

    // Observable list of all courses
    private final LiveData<List<Course>> allCourses;

    //Constructor initializes DAOs and LiveData for courses.
    public CourseRepository(Application application) {
        AppDatabase db = AppDatabase.getInstance(application);
        courseDao = db.courseDao();
        crossRefDao = db.courseStudentCrossRefDao();
        studentDao = db.studentDao();
        allCourses = courseDao.getAllCourses();
    }

    //Returns observable list of all courses in the database.
    public LiveData<List<Course>> getAllCourses() {
        return allCourses;
    }

    //Inserts a course into the database asynchronously
    public void insert(Course course) {
        AppDatabase.databaseWriteExecutor.execute(() -> {
            courseDao.insert(course);
        });
    }

    /**
     * Delete a course and its associated student links.
     * If a student is no longer enrolled in any other course,
     * the student is also removed as they are no longer enrolled in any course
     */
    public void delete(Course course) {
        AppDatabase.databaseWriteExecutor.execute(() -> {
            int courseId = course.getCourseId();

            // Step 1: Get all students linked to this course
            List<CourseStudentCrossRef> links = crossRefDao.getStudentsForCourse(courseId);
            List<Integer> affectedStudentIds = new ArrayList<>();
            for (CourseStudentCrossRef ref : links) {
                affectedStudentIds.add(ref.getStudentId());
            }

            // Step 2: Remove course-student relationships
            crossRefDao.deleteAllStudentsForCourse(courseId);

            // Step 3: Delete the course
            courseDao.delete(course);

            // Step 4: Remove orphaned students
            for (int studentId : affectedStudentIds) {
                List<CourseStudentCrossRef> remainingLinks = crossRefDao.getCoursesForStudent(studentId);
                if (remainingLinks.isEmpty()) {
                    studentDao.deleteById(studentId);
                }
            }
        });
    }
}
