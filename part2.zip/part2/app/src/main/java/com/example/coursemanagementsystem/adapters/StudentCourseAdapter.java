package com.example.coursemanagementsystem.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.coursemanagementsystem.R;
import com.example.coursemanagementsystem.database.entities.Course;

import java.util.ArrayList;
import java.util.List;

/**
 * RecyclerView Adapter for displaying a list of courses a student is enrolled in.
 * Used within StudentDetailsActivity to show course code and course name for each course.
 */
public class StudentCourseAdapter extends RecyclerView.Adapter<StudentCourseAdapter.ViewHolder> {

    private List<Course> courses = new ArrayList<>();

    // Update the list of courses and refresh the view
    public void setCourses(List<Course> courses) {
        this.courses = courses;
        notifyDataSetChanged();
    }

    // Inflate the student_course_item layout
    @NonNull
    @Override
    public StudentCourseAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.student_course_item, parent, false);
        return new ViewHolder(view);
    }

    // Bind course data to each view item
    @Override
    public void onBindViewHolder(@NonNull StudentCourseAdapter.ViewHolder holder, int position) {
        Course course = courses.get(position);
        holder.courseCode.setText(course.getCourseCode());
        holder.courseName.setText(course.getCourseName());
    }

    // Return total number of courses
    @Override
    public int getItemCount() {
        return courses.size();
    }

    // ViewHolder class for holding course views
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView courseCode, courseName;

        public ViewHolder(View itemView) {
            super(itemView);
            courseCode = itemView.findViewById(R.id.studentCourseCodeTextView);
            courseName = itemView.findViewById(R.id.studentCourseNameTextView);
        }
    }
}
