package com.example.coursemanagementsystem.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.coursemanagementsystem.R;
import com.example.coursemanagementsystem.database.AppDatabase;
import com.example.coursemanagementsystem.database.entities.Course;
import com.example.coursemanagementsystem.viewmodels.CourseViewModel;
import com.google.android.material.textfield.TextInputEditText;

/**
 * Activity for creating and saving a new course.
 * Provides input fields for course code, name, and lecturer.
 * Handles validation and inserts the course into the database via the CourseViewModel.
 * Returns to the main screen upon successful creation.
 */
public class CreateCourseActivity extends AppCompatActivity {

    // UI fields for input
    private TextInputEditText courseCodeEditText, courseNameEditText, lecturerNameEditText;

    // ViewModel for handling course database operations
    private CourseViewModel courseViewModel;

    // Capitalise Lecturer names and Course names
    private String capitalizeEachWord(String input) {
        String[] words = input.trim().split("\\s+");
        StringBuilder capitalized = new StringBuilder();

        for (String word : words) {
            if (word.length() > 0) {
                capitalized.append(Character.toUpperCase(word.charAt(0)))
                        .append(word.substring(1)).append(" ");
            }
        }

        return capitalized.toString().trim();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_course);

        // Show back button in the top action bar and set screen title
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Create Course");
        }

        // Initialize ViewModel
        courseViewModel = new ViewModelProvider(this).get(CourseViewModel.class);

        // Get references to input fields and button
        courseCodeEditText = findViewById(R.id.courseCodeEditText);
        courseNameEditText = findViewById(R.id.courseNameEditText);
        lecturerNameEditText = findViewById(R.id.lecturerNameEditText);
        Button createButton = findViewById(R.id.createCourseButton);

        // Handle button click to create course
        createButton.setOnClickListener(v -> createCourse());
    }

    // Handle back navigation from action bar
    @Override
    public boolean onSupportNavigateUp() {
        finish(); // Close this activity
        return true;
    }

    // Create and save a new course with validation
    private void createCourse() {
        String courseCode = courseCodeEditText.getText().toString().trim();
        String courseName = capitalizeEachWord(courseNameEditText.getText().toString().trim().toLowerCase());
        String lecturerName = capitalizeEachWord(lecturerNameEditText.getText().toString().trim().toLowerCase());

        // Check for empty fields
        if (courseCode.isEmpty() || courseName.isEmpty() || lecturerName.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate course code format: 2 capital letters + 4 digits (e.g. CS1234)
        if (!courseCode.matches("^[A-Z]{2}\\d{4}$")) {
            Toast.makeText(this, "Code should be 2 uppercase letters followed by 4 digits (e.g. CS1234)", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate lecturer full name (first + last name, no hyphens)
        if (!lecturerName.matches("^[A-Za-z]+\\s+[A-Za-z]+$")) {
            Toast.makeText(this, "Please use Lecturer's full name", Toast.LENGTH_SHORT).show();
            return;
        }

        // Run uniqueness check and insertion in background
        AppDatabase.databaseWriteExecutor.execute(() -> {
            boolean codeExists = AppDatabase.getInstance(getApplicationContext())
                    .courseDao()
                    .getAllCoursesNow()
                    .stream()
                    .anyMatch(c -> c.getCourseCode().equals(courseCode)); // Case-sensitive now

            runOnUiThread(() -> {
                if (codeExists) {
                    Toast.makeText(this, "Course code already exists", Toast.LENGTH_LONG).show();
                } else {
                    Course course = new Course(courseCode, courseName, lecturerName);
                    courseViewModel.insert(course);
                    Toast.makeText(this, "Course created successfully", Toast.LENGTH_SHORT).show();
                    finish(); // Return to MainActivity
                }
            });
        });
    }
}
