package com.example.coursemanagementsystem.viewmodels;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.coursemanagementsystem.database.entities.Course;
import com.example.coursemanagementsystem.database.entities.Student;
import com.example.coursemanagementsystem.repositories.StudentRepository;

import java.util.List;

/**
 * ViewModel for managing UI-related data for students.
 * Provides data to the UI and survives configuration changes.
 * Communicates with the StudentRepository to perform data operations.
 */
public class StudentViewModel extends AndroidViewModel {

    private final StudentRepository repository;
    private final LiveData<List<Student>> allStudents;

    //Initialize the ViewModel and fetch all students from the repository.
    public StudentViewModel(Application application) {
        super(application);
        repository = new StudentRepository(application);
        allStudents = repository.getAllStudents();
    }

    //Return a LiveData list of all students in the database.
    public LiveData<List<Student>> getAllStudents() {
        return allStudents;
    }

    //Insert a new student into the database.
    public void insert(Student student) {
        repository.insert(student);
    }

    //Delete a student from the database.
    public void delete(Student student) {
        repository.delete(student);
    }

    //Retrieve all students enrolled in a specific course.
    public LiveData<List<Student>> getStudentsByCourseId(int courseId) {
        return repository.getStudentsByCourseId(courseId);
    }

    //Retrieve all courses a specific student is enrolled in.
    public LiveData<List<Course>> getCoursesForStudent(int studentId) {
        return repository.getCoursesForStudent(studentId);
    }

    //Retrieve a specific student by their ID.
    public LiveData<Student> getStudentById(int studentId) {
        return repository.getStudentById(studentId);
    }
}
