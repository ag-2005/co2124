package com.example.coursemanagementsystem.activities;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.coursemanagementsystem.R;
import com.example.coursemanagementsystem.adapters.StudentCourseAdapter;
import com.example.coursemanagementsystem.viewmodels.StudentViewModel;

/**
 * Displays detailed information about a specific student.
 * Shows the student's name, email, matric number, and the list of courses they are enrolled in.
 * Provides a back button in the action bar and uses a ViewModel to observe student data.
 * Used when a student is tapped from a course's student list.
 */
public class StudentDetailsActivity extends AppCompatActivity {

    // Key used to receive the student ID from the intent
    public static final String EXTRA_STUDENT_ID = "studentId";

    // UI references
    private TextView nameTextView, emailTextView, matricTextView;
    private RecyclerView enrolledCoursesRecyclerView;
    private StudentCourseAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_details);

        // Show back button in the top action bar and set screen title
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Student Details");
        }

        // Bind UI components
        nameTextView = findViewById(R.id.studentNameTextView);
        emailTextView = findViewById(R.id.studentEmailTextView);
        matricTextView = findViewById(R.id.studentMatricTextView);
        enrolledCoursesRecyclerView = findViewById(R.id.enrolledCoursesRecyclerView);

        // Setup RecyclerView
        adapter = new StudentCourseAdapter();
        enrolledCoursesRecyclerView.setAdapter(adapter);
        enrolledCoursesRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Retrieve student ID from intent
        int studentId = getIntent().getIntExtra(EXTRA_STUDENT_ID, -1);

        // Initialize ViewModel
        StudentViewModel viewModel = new ViewModelProvider(this).get(StudentViewModel.class);

        // Observe student details
        viewModel.getStudentById(studentId).observe(this, student -> {
            if (student != null) {
                nameTextView.setText(student.getName());
                emailTextView.setText(student.getEmail());
                matricTextView.setText(student.getUserName());
            }
        });

        // Observe and display enrolled courses
        viewModel.getCoursesForStudent(studentId).observe(this, courses -> {
            adapter.setCourses(courses);
        });
    }

    // Handle back arrow press
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish(); // Close activity and return to previous screen
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
