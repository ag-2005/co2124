package com.example.coursemanagementsystem.database.daos;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.coursemanagementsystem.database.entities.Student;

import java.util.List;

/**
 * Data Access Object (DAO) for interacting with the Student table.
 * Provides methods to insert, delete, and query student records,
 * including operations for validation and enrollment tracking.
 */
@Dao
public interface StudentDao {

    // Insert a new student into the database
    @Insert
    void insert(Student student);

    // Delete a specific student
    @Delete
    void delete(Student student);

    // Delete all students from the table
    @Query("DELETE FROM students")
    void deleteAllStudents();

    // Get all students, ordered alphabetically by name
    @Query("SELECT * FROM students ORDER BY name ASC")
    LiveData<List<Student>> getAllStudents();

    // Get a single student by ID
    @Query("SELECT * FROM students WHERE studentId = :studentId")
    LiveData<Student> getStudentById(int studentId);

    // Get all students enrolled in a specific course
    @Query("SELECT s.* FROM students s INNER JOIN CourseStudentCrossRef c ON s.studentId = c.studentId WHERE c.courseId = :courseId")
    LiveData<List<Student>> getStudentsByCourseId(int courseId);

    // Find a student by metric number (username) - used for validation
    @Query("SELECT * FROM students WHERE userName = :username LIMIT 1")
    Student findStudentByUsername(String username);

    // Get a student by metric number after insert
    @Query("SELECT * FROM students WHERE userName = :username LIMIT 1")
    Student getStudentByUsername(String username);

    // Find a student by email - used for validation
    @Query("SELECT * FROM students WHERE email = :email LIMIT 1")
    Student findStudentByEmail(String email);

    // Delete a student by their ID
    @Query("DELETE FROM students WHERE studentId = :studentId")
    void deleteById(int studentId);
}
