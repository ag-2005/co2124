package com.example.coursemanagementsystem.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.coursemanagementsystem.R;
import com.example.coursemanagementsystem.database.AppDatabase;
import com.example.coursemanagementsystem.database.entities.CourseStudentCrossRef;
import com.example.coursemanagementsystem.database.entities.Student;
import com.google.android.material.textfield.TextInputEditText;

import java.util.List;

/**
 * Activity for adding a new student to a specific course.
 * Performs input validation, ensures student uniqueness by name/email/matric,
 * creates the student if they don't exist, and links them to the selected course.
 * If the student is already linked, a message is shown instead.
 */
public class AddStudentActivity extends AppCompatActivity {

    private TextInputEditText nameEditText, emailEditText, userNameEditText;
    private AppDatabase db;
    private int courseId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Show back button in the top action bar and set screen title
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Add Student");
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_student);

        // Initialize UI components
        nameEditText = findViewById(R.id.studentNameEditText);
        emailEditText = findViewById(R.id.studentEmailEditText);
        userNameEditText = findViewById(R.id.studentUsernameEditText);
        Button addButton = findViewById(R.id.addStudentButton);

        // Get database instance and course ID passed from previous screen
        db = AppDatabase.getInstance(getApplicationContext());
        courseId = getIntent().getIntExtra(CourseDetailsActivity.EXTRA_COURSE_ID, -1);

        // Handle Add button click
        addButton.setOnClickListener(v -> addStudent());
    }

    // Handle toolbar back button click
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    // Adds a student to the database and links them to the course
    private void addStudent() {
        // Fetch user input
        String name = nameEditText.getText().toString().trim();
        String email = emailEditText.getText().toString().trim();
        String username = userNameEditText.getText().toString().trim().toLowerCase(); // Normalize to lowercase

        // Check for empty fields
        if (name.isEmpty() || email.isEmpty() || username.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate full name (must contain first and last name with valid characters)
        if (!name.matches("^[A-Za-z]+(?:[-'][A-Za-z]+)*\\s+[A-Za-z]+(?:[-'][A-Za-z]+)*$") || name.startsWith("-")) {
            Toast.makeText(this, "Enter first & last name using letters/hyphens only", Toast.LENGTH_LONG).show();
            return;
        }

        // Validate email format and known TLDs
        if (!email.matches("^[\\w.-]+@[A-Za-z0-9.-]+\\.(com|org|net|gov|edu|uk|co\\.uk|ac\\.uk|io|info|dev|ai|[a-z]{2})$")) {
            Toast.makeText(this, "Invalid email format", Toast.LENGTH_LONG).show();
            return;
        }

        // Validate matric format (e.g., wh123)
        String[] nameParts = name.split("\\s+");
        String expectedPrefix = (nameParts[0].substring(0, 1) + nameParts[1].substring(0, 1)).toLowerCase();
        if (!username.toLowerCase().matches(expectedPrefix + "\\d{1,3}")) {
            Toast.makeText(this, "Matric must begin with initials (e.g. " + expectedPrefix + ") and end in 1–3 digits", Toast.LENGTH_LONG).show();
            return;
        }

        // Perform DB insertions in background thread
        AppDatabase.databaseWriteExecutor.execute(() -> {
            // Check if student already exists by username or email
            Student existingByMatric = db.studentDao().findStudentByUsername(username);
            Student existingByEmail = db.studentDao().findStudentByEmail(email);
            int studentId;

            if (existingByMatric != null) {
                // If username is taken, check for matching name and email
                boolean emailMatches = existingByMatric.getEmail().equals(email);
                boolean nameMatches = existingByMatric.getName().equals(name);

                if (!emailMatches || !nameMatches) {
                    runOnUiThread(() -> Toast.makeText(this, "Student details already in use. Please check for typos.", Toast.LENGTH_LONG).show());
                    return;
                }

                // Existing student is valid
                studentId = existingByMatric.getStudentId();
            } else if (existingByEmail != null) {
                // Email taken by another student
                runOnUiThread(() -> Toast.makeText(this, "Email already in use by a different student.", Toast.LENGTH_LONG).show());
                return;
            } else {
                // Create new student
                Student newStudent = new Student(name, email, username);
                db.studentDao().insert(newStudent);
                studentId = db.studentDao().getStudentByUsername(username).getStudentId();
            }

            // Check if student is already enrolled in this course
            List<CourseStudentCrossRef> links = db.courseStudentCrossRefDao().getStudentsForCourse(courseId);
            boolean alreadyEnrolled = false;
            for (CourseStudentCrossRef ref : links) {
                if (ref.getStudentId() == studentId) {
                    alreadyEnrolled = true;
                    break;
                }
            }

            // Add student to course if not already enrolled
            if (alreadyEnrolled) {
                runOnUiThread(() -> Toast.makeText(this, "Student already enrolled in this course", Toast.LENGTH_SHORT).show());
            } else {
                db.courseStudentCrossRefDao().insert(new CourseStudentCrossRef(courseId, studentId));
                runOnUiThread(() -> {
                    Toast.makeText(this, "Student added", Toast.LENGTH_SHORT).show();
                    finish(); // Go back after successful addition
                });
            }
        });
    }
}
