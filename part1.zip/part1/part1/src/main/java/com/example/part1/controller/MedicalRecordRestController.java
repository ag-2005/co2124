package com.example.part1.controller;

import com.example.part1.domain.Appointments;
import com.example.part1.domain.ErrorInfo;
import com.example.part1.repo.AppointmentRepo;
import com.example.part1.repo.RecordRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import com.example.part1.domain.Record;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.util.UriComponentsBuilder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MedicalRecordRestController {

    @Autowired
    private RecordRepo recordRepo;

    @Autowired
    private AppointmentRepo appointmentRepo;

    //  Create a new medical record (POST /medical-records) (endpoint #20)
    @PostMapping("/medical-records")
    public ResponseEntity<?> createMedicalRecord(@RequestBody Record record, UriComponentsBuilder ucBuilder){

        Long appointmentId = record.getAppointments().getId();
        Appointments appointment = appointmentRepo.findById(appointmentId).orElse(null);

        if (appointment == null) {
            return new ResponseEntity<>(new ErrorInfo("Appointment with id " + appointmentId + " does not exist."), HttpStatus.NOT_FOUND);
        }

        if (recordRepo.existsByAppointments(appointment)) {
            return new ResponseEntity<>(new ErrorInfo("Appointment already has a medical record"), HttpStatus.CONFLICT);
        }

        record.setAppointments(appointment);
        recordRepo.save(record);
        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(ucBuilder.path("/medical-records").build().toUri());
        return new ResponseEntity<>(headers, HttpStatus.CREATED);
    }

}
