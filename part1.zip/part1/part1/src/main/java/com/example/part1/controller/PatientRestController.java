package com.example.part1.controller;

import com.example.part1.domain.*;
import com.example.part1.domain.Record;
import com.example.part1.repo.DoctorRepo;
import com.example.part1.repo.PatientRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.ArrayList;
import java.util.List;

@RestController
public class PatientRestController {

    @Autowired
    PatientRepo patientRepo;

    @Autowired
    DoctorRepo doctorRepo;

    //  List all patients (GET /patients) (endpoint #1)
    @GetMapping("/patients")
    public ResponseEntity<?> listAllPatients() {
        List<Patient> patients = patientRepo.findAll();
        return new ResponseEntity<List<Patient>>(patients, HttpStatus.OK);
    }

    //  Create a new patient (POST /patients) (endpoint #2)
    @PostMapping("/patients")
    public ResponseEntity<?> createPatient(@RequestBody Patient patient, UriComponentsBuilder ucBuilder) {

        if (patient.getName() == null || patient.getEmail() == null || patient.getPhoneNumber() == null || patient.getAddress() == null) {
            return new ResponseEntity<>(new ErrorInfo("Missing required patient information."), HttpStatus.BAD_REQUEST);
        }

        patientRepo.save(patient);
        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(ucBuilder.path("/patients/{id}").buildAndExpand(patient.getId()).toUri());
        return new ResponseEntity<String>(headers, HttpStatus.CREATED);
    }

    //  Retrieve a specific patient by ID (GET /patients/{id}) (endpoint #3)
    @GetMapping("/patients/{id}")
    public ResponseEntity<?> findPatient(@PathVariable("id") long id) {
        Patient patient = patientRepo.findById(id).orElse(null);
        if (patient == null) {
            return new ResponseEntity<>(new ErrorInfo("Patient with id " + id + " not found"), HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Patient>(patient, HttpStatus.OK);
    }

    //  Update a specific patient by ID (PUT /patients/{id}) (endpoint #4)
    @PutMapping("/patients/{id}")
    public ResponseEntity<?> updatePatient(@PathVariable("id") long id, @RequestBody Patient patient) {
        Patient currentPatient = patientRepo.findById(id).orElse(null);

        if (currentPatient == null) {
            return new ResponseEntity<>(new ErrorInfo("Patient with id " + id + " not found "), HttpStatus.NOT_FOUND);
        }

        currentPatient.setName(patient.getName());
        currentPatient.setEmail(patient.getEmail());
        currentPatient.setAddress(patient.getAddress());
        currentPatient.setPhoneNumber(String.valueOf(patient.getPhoneNumber()));
        patientRepo.save(currentPatient);

        return new ResponseEntity<Patient>(currentPatient, HttpStatus.OK);
    }

    //  Delete a specific patient by ID (DELETE /patients/{id}) (endpoint #5)
    @DeleteMapping("/patients/{id}")
    public ResponseEntity<?> deletePatient(@PathVariable("id") long id) {
        Patient patient = patientRepo.findById(id).orElse(null);
        if (patient == null) {
            return new ResponseEntity<>(new ErrorInfo("Patient with id " + id + " not found "), HttpStatus.NOT_FOUND);
        }
        patientRepo.delete(patient);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    //  List all appointments for a specific patient (GET /patients/{id}/appointments) (endpoint #6)
    @GetMapping("/patients/{id}/appointments")
    public ResponseEntity<?> listAppointments(@PathVariable long id) {
        Patient patient = patientRepo.findById(id).orElse(null);
        if (patient == null) {
            return new ResponseEntity(new ErrorInfo("Patient with id " + id + " not found "), HttpStatus.NOT_FOUND);
        }

        List<Appointments> appointments = patient.getAppointments();
        return new ResponseEntity<>(appointments, HttpStatus.OK);
    }

    //  List all medical records for a specific patient (GET /patients/{id}/medical-records) (endpoint #7)
    @GetMapping("/patients/{id}/medical-records")
    public ResponseEntity<?> listMedicalRecords(@PathVariable long id) {
        Patient patient = patientRepo.findById(id).orElse(null);
        if (patient == null) {
            return new ResponseEntity<>(new ErrorInfo("Patient with id " + id + " not found "), HttpStatus.NOT_FOUND);
        }

        List<Record> records = new ArrayList<>();
        for (Appointments appointments : patient.getAppointments()) {
            Record record = appointments.getRecord();
            if (record != null) {
                records.add(record);
            }
        }

        return new ResponseEntity<>(records, HttpStatus.OK);
    }

}
