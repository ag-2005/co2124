package com.example.part1.repo;

import com.example.part1.domain.Appointments;
import com.example.part1.domain.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PatientRepo extends JpaRepository<Patient, Long> {
    // No need to implement anything here, JpaRepository handles the CRUD operations
}
