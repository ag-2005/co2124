package com.example.part1.controller;


import com.example.part1.domain.*;
import com.example.part1.domain.Record;
import com.example.part1.repo.AppointmentRepo;
import com.example.part1.repo.DoctorRepo;
import com.example.part1.repo.PatientRepo;
import com.example.part1.repo.RecordRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import java.sql.Timestamp;
import java.util.List;

@RestController
public class AppointmentRestController {

    @Autowired
    private AppointmentRepo appointmentRepo;

    @Autowired
    private RecordRepo recordRepo;

    @Autowired
    private PatientRepo patientRepo;

    @Autowired
    private DoctorRepo doctorRepo;

    //  List all appointments (GET /appointments) (endpoint #14)
    @GetMapping("/appointments")
    public ResponseEntity<List<Appointments>> listAllAppointments() {
        List<Appointments> appointments = appointmentRepo.findAll();
        return new ResponseEntity<>(appointments, HttpStatus.OK);
    }

    //  Create a new appointment (POST /appointments) (endpoint #15)
    @PostMapping("/appointments")
    public ResponseEntity<?> addAppointment(@RequestBody Appointments appointment, UriComponentsBuilder ucBuilder) {

        if (appointment.getPatient() != null) {
            long patientId = appointment.getPatient().getId();
            Patient patient = patientRepo.findById(patientId).orElse(null);
            if (patient == null) {
                return new ResponseEntity<>(new ErrorInfo("Invalid patient reference: No patient found with id " + patientId), HttpStatus.BAD_REQUEST);
            }
            appointment.setPatient(patient);
        }

        if (appointment.getDoctor() != null && appointment.getDoctor().getId() > 0) {
            long doctorId = appointment.getDoctor().getId();
            Doctor doctor = doctorRepo.findById(doctorId).orElse(null);
            if (doctor == null) {
                return new ResponseEntity<>(new ErrorInfo("Invalid doctor reference: No doctor found with id " + doctorId), HttpStatus.BAD_REQUEST);
            }
            appointment.setDoctor(doctor);
        }


        appointmentRepo.save(appointment);
        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(ucBuilder.path("/appointments/{id}").buildAndExpand(appointment.getId()).toUri());
        return new ResponseEntity<String>(headers, HttpStatus.CREATED);
    }

    //  Retrieve a specific appointment by ID (GET /appointments/{id}) (endpoint #16)
    @GetMapping("/appointments/{id}")
    public ResponseEntity<?> getAppointmentById(@PathVariable("id") long id) {
        Appointments appointment = appointmentRepo.findById(id).orElse(null);
        if (appointment == null) {
            return new ResponseEntity<>(new ErrorInfo("Appointment with the id " + id + " does not exist. "), HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<Appointments>(appointment, HttpStatus.OK);
    }

    //  Update a specific appointment by ID (PUT /appointments/{id}) (endpoint #17)
    @PutMapping("/appointments/{id}")
    public ResponseEntity<?> updateAppointment(@PathVariable("id") long id, @RequestBody Appointments appointment) {
        Appointments currentAppointment = appointmentRepo.findById(id).orElse(null);
        if (currentAppointment == null) {
            return new ResponseEntity<>(new ErrorInfo("Appointment with the id " + id + " does not exist. "), HttpStatus.NOT_FOUND);
        }

        currentAppointment.setAppointmentDate(appointment.getAppointmentDate());
        currentAppointment.setStatus(appointment.getStatus());
        currentAppointment.setNotes(appointment.getNotes());
        currentAppointment.setDoctor(appointment.getDoctor());
        currentAppointment.setPatient(appointment.getPatient());
        appointmentRepo.save(currentAppointment);
        return new ResponseEntity<Appointments>(currentAppointment, HttpStatus.OK);
    }

    //  Delete a specific appointment by ID (DELETE /appointments/{id}) (endpoint #18)
    @DeleteMapping("/appointments/{id}")
    public ResponseEntity<?> deleteAppointment(@PathVariable("id") long id) {
        Appointments appointments = appointmentRepo.findById(id).orElse(null);
        if (appointments == null) {
            return new ResponseEntity<>(new ErrorInfo("Appointment with the id " + id + " does not exist. "), HttpStatus.NOT_FOUND);
        }

        Record record = appointments.getRecord();
        if (record != null) {
            appointments.setRecord(null);
            recordRepo.delete(record);
        }

        appointmentRepo.delete(appointments);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    //  Retrieve the medical record for a specific appointment (GET appointments/{id}/medical-record) (endpoint #19)
    @GetMapping("/appointments/{id}/medical-record")
    public ResponseEntity<?> getMedicalRecord(@PathVariable("id") long id) {
        Appointments appointments = appointmentRepo.findById(id).orElse(null);
        if (appointments == null) {
            return new ResponseEntity<>(new ErrorInfo("Appointment with the id " + id + " does not exist. "), HttpStatus.NOT_FOUND);
        }

        Record record = appointments.getRecord();
        return new ResponseEntity<>(record, HttpStatus.OK);
    }
}
