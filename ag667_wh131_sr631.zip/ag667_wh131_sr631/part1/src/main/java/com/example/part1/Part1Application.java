package com.example.part1;

import com.example.part1.domain.Appointments;
import com.example.part1.domain.Doctor;
import com.example.part1.domain.Record;
import com.example.part1.domain.Patient;
import com.example.part1.repo.AppointmentRepo;
import com.example.part1.repo.DoctorRepo;
import com.example.part1.repo.PatientRepo;
import com.example.part1.repo.RecordRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.sql.Timestamp;
import java.time.LocalDateTime;

@SpringBootApplication
public class Part1Application implements CommandLineRunner {

	@Autowired
	private PatientRepo patientRepo;

	@Autowired
	private DoctorRepo doctorRepo;

	@Autowired
	private AppointmentRepo appointmentRepo;

	@Autowired
	private RecordRepo recordRepo;

	public static void main(String[] args) { SpringApplication.run(Part1Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		Doctor doctor = new Doctor();
		doctor.setName("Dr. Jane Doe");
		doctor.setSpecialisation("Neurology");
		doctor.setEmail("jane.doe@hospital.com");
		doctor.setPhoneNumber("+4476543210");
		doctorRepo.save(doctor);

		Doctor doctor2 = new Doctor();
		doctor2.setName("Dr. John Save");
		doctor2.setSpecialisation("Surgeon");
		doctor2.setEmail("john.save@hospital.com");
		doctor2.setPhoneNumber("+4476543210");
		doctorRepo.save(doctor2);

		Patient patient = new Patient();
		patient.setName("John Smith");
		patient.setEmail("john.smith@example.com");
		patient.setPhoneNumber("+1234567890");
		patient.setAddress("456 Elm Street");
		patientRepo.save(patient);

		Patient patient2 = new Patient();
		patient2.setName("Luke Nevis");
		patient2.setEmail("luke@example.com");
		patient2.setPhoneNumber("+4476543213");
		patient2.setAddress("4 Elf Street");
		patientRepo.save(patient2);

		Appointments appointments = new Appointments();
		appointments.setStatus("Scheduled");
		appointments.setNotes("Headache");
		appointments.setAppointmentDate(Timestamp.valueOf(LocalDateTime.now().plusDays(67)));
		appointments.setDoctor(doctor);
		appointments.setPatient(patient);
		appointmentRepo.save(appointments);

		System.out.println("Sample patient, doctor, appointment and medical record saved on Part1Application.java for testing purposes");
	}
}
