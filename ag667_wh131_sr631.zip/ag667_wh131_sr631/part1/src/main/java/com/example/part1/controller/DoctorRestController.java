package com.example.part1.controller;

import com.example.part1.domain.Appointments;
import com.example.part1.domain.Doctor;
import com.example.part1.domain.ErrorInfo;
import com.example.part1.domain.Patient;
import com.example.part1.domain.Record;
import com.example.part1.repo.AppointmentRepo;
import com.example.part1.repo.DoctorRepo;
import com.example.part1.repo.PatientRepo;
import com.example.part1.repo.RecordRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import javax.print.Doc;
import java.util.ArrayList;
import java.util.List;

@RestController
public class DoctorRestController {

    @Autowired
    private DoctorRepo doctorRepo;

    @Autowired
    private AppointmentRepo appointmentRepo;

    @Autowired
    private RecordRepo recordRepo;

    //  List all doctors (GET /doctors) (endpoint #8)
    @GetMapping("/doctors")
    public ResponseEntity<List<Doctor>> listAllDoctors() {
        List<Doctor> doctors = doctorRepo.findAll();
        return new ResponseEntity<>(doctors, HttpStatus.OK);
    }

    //  Create a new doctor (POST /doctors) (endpoint #9)
    @PostMapping("/doctors")
    public ResponseEntity<?> createDoctor(@RequestBody Doctor doctor, UriComponentsBuilder ucBuilder) {

        if (doctor.getName() == null || doctor.getEmail() == null || doctor.getPhoneNumber() == null || doctor.getSpecialisation() == null) {
            return new ResponseEntity<>(new ErrorInfo("Missing required doctor information."), HttpStatus.BAD_REQUEST);
        }

        doctorRepo.save(doctor);
        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(ucBuilder.path("/doctors/{id}").buildAndExpand(doctor.getId()).toUri());
        return new ResponseEntity<String>(headers, HttpStatus.CREATED);
    }

    //  Retrieve a specific doctor by ID (GET /doctors/{id}) (endpoint #10)
    @GetMapping("/doctors/{id}")
    public ResponseEntity<?> findDoctor(@PathVariable("id") long id) {
        Doctor doctor = doctorRepo.findById(id).orElse(null);
        if (doctor == null) {
            return new ResponseEntity<>(new ErrorInfo("Doctor with id " + id + " not found"), HttpStatus.NOT_FOUND);
        }

        for (Appointments appointment : doctor.getAppointments()) {
            appointment.setDoctor(doctor);
        }

        return new ResponseEntity<Doctor>(doctor, HttpStatus.OK);
    }

    //  Update a specific doctor by ID (PUT /doctors/{id}) (endpoint #11)
    @PutMapping("/doctors/{id}")
    public ResponseEntity<?> updateDoctor(@RequestBody Doctor doctor, @PathVariable("id") long id) {
        Doctor currentDoctor = doctorRepo.findById(id).orElse(null);
        if (currentDoctor == null) {
            return new ResponseEntity<>(new ErrorInfo("Doctor with id " + id + " not found "), HttpStatus.NOT_FOUND);
        }

        currentDoctor.setName(doctor.getName());
        currentDoctor.setEmail(doctor.getEmail());
        currentDoctor.setSpecialisation(doctor.getSpecialisation());
        currentDoctor.setPhoneNumber(doctor.getPhoneNumber());
        doctorRepo.save(currentDoctor);

        return new ResponseEntity<Doctor>(currentDoctor, HttpStatus.OK);
    }

    //  Delete a specific doctor by ID (DELETE /doctors/{id}) (endpoint #12)
    @DeleteMapping("/doctors/{id}")
    public ResponseEntity<?> deleteDoctor(@PathVariable("id") long id) {
        Doctor doctor = doctorRepo.findById(id).orElse(null);
        if (doctor == null) {
            return new ResponseEntity<>(new ErrorInfo("Doctor with id " + id + " not found"), HttpStatus.NOT_FOUND);
        }

        List<Appointments> appointments = doctor.getAppointments();

        // Unlink relationship between Appointment and Record to ensure Record is saved
        for (Appointments appointment : appointments) {
            if (appointment.getRecord() != null) {
                Record record = appointment.getRecord();
                record.setAppointments(null);
                recordRepo.save(record);
                appointment.setRecord(null);
            }
        }

        doctor.getAppointments().clear();
        doctorRepo.save(doctor);
        appointmentRepo.deleteAll(appointments);
        doctorRepo.delete(doctor);

        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    //  List all appointments for a specific doctor (GET /doctors/{id}/appointments) (endpoint #13)
    @GetMapping("/doctors/{id}/appointments")
    public ResponseEntity<?> listAppointments(@PathVariable("id") long id) {
        Doctor doctor = doctorRepo.findById(id).orElse(null);
        if (doctor == null) {
            return new ResponseEntity<>(new ErrorInfo("Doctor with id " + id + " not found "), HttpStatus.NOT_FOUND); // status 404
        }

        List<Appointments> appointments = doctor.getAppointments();
        if (appointments == null) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }

        return new ResponseEntity<List<Appointments>>(appointments, HttpStatus.OK);
    }
}
