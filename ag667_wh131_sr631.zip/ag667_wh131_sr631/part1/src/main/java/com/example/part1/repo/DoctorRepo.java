package com.example.part1.repo;

import com.example.part1.domain.Doctor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DoctorRepo extends JpaRepository<Doctor, Long> {
    // No need to implement anything here, JpaRepository handles the CRUD operations
}
