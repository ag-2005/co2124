package com.example.coursemanagementsystem.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.coursemanagementsystem.R;
import com.example.coursemanagementsystem.database.AppDatabase;
import com.example.coursemanagementsystem.database.entities.CourseStudentCrossRef;
import com.example.coursemanagementsystem.database.entities.Student;
import com.google.android.material.textfield.TextInputEditText;

/**
 * Activity for editing an existing student's information.
 * Loads current student data into input fields and allows updates to:
 * - Full name (first + last)
 * - Email address
 * - Matric number (username)
 * Handles validation and updates the student in the database.
 * Returns to the previous screen upon successful update.
 */
public class EditStudentActivity extends AppCompatActivity {

    // Key for retrieving student ID passed via intent
    public static final String EXTRA_STUDENT_ID = "editStudentId";

    // UI fields for input
    private TextInputEditText nameEditText, emailEditText, userNameEditText;

    // Database instance and target student ID
    private AppDatabase db;
    private int studentId;

    // Course ID passed from previous screen (kept but not used in edit logic)
    private int courseId;

    // Capitalizes each word in a name (e.g., "john doe" → "John Doe")
    private String capitalizeEachWord(String input) {
        String[] words = input.trim().split("\\s+");
        StringBuilder capitalized = new StringBuilder();

        for (String word : words) {
            if (word.length() > 0) {
                capitalized.append(Character.toUpperCase(word.charAt(0)))
                        .append(word.substring(1)).append(" ");
            }
        }

        return capitalized.toString().trim();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_student); // Reusing add student layout for editing

        // Show back button in the top action bar and set screen title
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Edit Student");
        }

        // Get references to UI fields
        nameEditText = findViewById(R.id.studentNameEditText);
        emailEditText = findViewById(R.id.studentEmailEditText);
        userNameEditText = findViewById(R.id.studentUsernameEditText);
        Button saveButton = findViewById(R.id.addStudentButton);
        saveButton.setText("Save"); // Change button label to "Save"

        // Initialize database and get intent extras
        db = AppDatabase.getInstance(getApplicationContext());
        studentId = getIntent().getIntExtra(EXTRA_STUDENT_ID, -1);
        courseId = getIntent().getIntExtra(CourseDetailsActivity.EXTRA_COURSE_ID, -1); // for consistency, not used here

        // Load current student details and populate the input fields
        AppDatabase.databaseWriteExecutor.execute(() -> {
            Student student = db.studentDao().getStudentByIdSync(studentId);

            runOnUiThread(() -> {
                if (student != null) {
                    nameEditText.setText(student.getName());
                    emailEditText.setText(student.getEmail());
                    userNameEditText.setText(student.getUserName()); // show raw casing
                }
            });
        });

        // Handle Save button click to update the student
        saveButton.setOnClickListener(v -> updateStudent());
    }

    /**
     * Validates and updates the student's information in the database.
     * Shows relevant error messages if any input is invalid.
     */
    private void updateStudent() {
        String rawName = nameEditText.getText().toString().trim();
        String name = capitalizeEachWord(rawName.toLowerCase());

        String email = emailEditText.getText().toString().trim();
        String rawUsername = userNameEditText.getText().toString().trim();      // keep original for display
        String username = rawUsername.toLowerCase();                            // save lowercase for uniqueness

        // Ensure all fields are filled
        if (name.isEmpty() || email.isEmpty() || rawUsername.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate full name: must be first + last name (no hyphens)
        if (!name.matches("^[A-Za-z]+\\s+[A-Za-z]+$")) {
            Toast.makeText(this, "Please use student's full name", Toast.LENGTH_LONG).show();
            return;
        }

        // Validate email format
        if (!email.matches("^[\\w.-]+@[A-Za-z0-9.-]+\\.(com|org|net|gov|edu|uk|co\\.uk|ac\\.uk|io|info|dev|ai|[a-z]{2})$")) {
            Toast.makeText(this, "Invalid email format", Toast.LENGTH_LONG).show();
            return;
        }

        // Validate username (matric) format: 2 letters + 1–3 digits
        //if (!username.matches("^[a-zA-Z]{2}\\d{1,3}$")) {
        //Toast.makeText(this, "Username must be 2 letters followed by up to 3 numbers", Toast.LENGTH_LONG).show();
        //return;
        //}

        // Perform DB operations in background thread
        AppDatabase.databaseWriteExecutor.execute(() -> {
            Student existingByMatric = db.studentDao().findStudentByUsername(username);
            Student existingByEmail = db.studentDao().findStudentByEmail(email);

            // Prevent username conflict with another student
            if (existingByMatric != null && existingByMatric.getStudentId() != studentId) {
                runOnUiThread(() -> Toast.makeText(this, "Username already in use by another student.", Toast.LENGTH_LONG).show());
                return;
            }

            // Prevent email conflict with another student
            if (existingByEmail != null && existingByEmail.getStudentId() != studentId) {
                runOnUiThread(() -> Toast.makeText(this, "Email already in use by another student.", Toast.LENGTH_LONG).show());
                return;
            }

            // Save the updated student in the database (username always lowercased)
            Student updatedStudent = new Student(name, email, username);
            updatedStudent.setStudentId(studentId); // Maintain original ID
            db.studentDao().update(updatedStudent);

            runOnUiThread(() -> {
                Toast.makeText(this, "Student updated", Toast.LENGTH_SHORT).show();
                finish(); // Return to previous screen
            });
        });
    }

    // Handle back navigation from action bar
    @Override
    public boolean onSupportNavigateUp() {
        finish(); // Close this activity
        return true;
    }
}
