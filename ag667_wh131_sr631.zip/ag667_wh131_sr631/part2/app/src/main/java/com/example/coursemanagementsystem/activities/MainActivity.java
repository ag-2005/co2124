package com.example.coursemanagementsystem.activities;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.coursemanagementsystem.R;
import com.example.coursemanagementsystem.adapters.CourseAdapter;
import com.example.coursemanagementsystem.database.entities.Course;
import com.example.coursemanagementsystem.viewmodels.CourseViewModel;
import com.example.coursemanagementsystem.viewmodels.StudentViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

/**
 * Main landing screen of the app.
 * Displays a list of all courses along with summary stats (total courses and students).
 * Allows users to view course details, create new courses, and delete existing ones.
 * Acts as the entry point for navigating to other parts of the system.
 */
public class MainActivity extends AppCompatActivity {

    private CourseAdapter adapter;
    private final List<Course> courses = new ArrayList<>();

    private CourseViewModel courseViewModel;

    @SuppressLint("NotifyDataSetChanged")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Configure the custom toolbar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowTitleEnabled(true);
            getSupportActionBar().setDisplayShowCustomEnabled(true);
            getSupportActionBar().setCustomView(R.layout.centered_toolbar_title);
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Setup RecyclerView for displaying courses
        RecyclerView coursesRecyclerView = findViewById(R.id.coursesRecyclerView);
        coursesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new CourseAdapter(courses);
        coursesRecyclerView.setAdapter(adapter);

        // Setup ViewModel for course operations and observe course list
        courseViewModel = new ViewModelProvider(this).get(CourseViewModel.class);
        TextView courseCountText = findViewById(R.id.totalCoursesCount);
        TextView emptyCoursesMessage = findViewById(R.id.emptyCoursesMessage); // 👈 new

        courseViewModel.getAllCourses().observe(this, courseList -> {
            courses.clear();
            courses.addAll(courseList);
            adapter.notifyDataSetChanged();

            // Update course count
            courseCountText.setText(String.valueOf(courseList.size()));

            // Show or hide empty state message
            emptyCoursesMessage.setVisibility(courseList.isEmpty() ? View.VISIBLE : View.GONE);
        });


        // Setup ViewModel to observe student count across all courses
        TextView studentCountText = findViewById(R.id.totalStudentsCount);
        StudentViewModel studentViewModel = new ViewModelProvider(this).get(StudentViewModel.class);
        studentViewModel.getAllStudents().observe(this, studentList -> {
            // Update the total number of students
            studentCountText.setText(String.valueOf(studentList.size()));
        });

        // Setup FloatingActionButton for creating a new course
        FloatingActionButton fab = findViewById(R.id.addCourseFab);
        fab.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, CreateCourseActivity.class);
            startActivity(intent);
        });

        // Navigate to course details when a course is tapped
        adapter.setOnItemClickListener(course -> {
            Intent intent = new Intent(MainActivity.this, CourseDetailsActivity.class);
            intent.putExtra(CourseDetailsActivity.EXTRA_COURSE_ID, course.getCourseId());
            intent.putExtra(CourseDetailsActivity.EXTRA_COURSE_CODE, course.getCourseCode());
            intent.putExtra(CourseDetailsActivity.EXTRA_COURSE_NAME, course.getCourseName());
            intent.putExtra(CourseDetailsActivity.EXTRA_LECTURER_NAME, course.getLecturerName());
            startActivity(intent);
        });

        // Prompt user to confirm before deleting a course on long press
        adapter.setOnItemLongClickListener(course -> {
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Delete Course")
                    .setMessage("Are you sure you want to delete this course?")
                    .setPositiveButton("Delete", (dialog, which) -> {
                        courseViewModel.delete(course);
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });
    }
}
