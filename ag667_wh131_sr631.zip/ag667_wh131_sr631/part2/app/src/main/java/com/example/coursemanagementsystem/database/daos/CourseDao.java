package com.example.coursemanagementsystem.database.daos;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.coursemanagementsystem.database.entities.Course;

import java.util.List;

/**
 * Data Access Object (DAO) for performing database operations related to courses.
 * Provides methods to insert, delete, and retrieve course data, as well as
 * fetch courses associated with a specific student.
 */
@Dao
public interface CourseDao {

    // Insert a new course into the database
    @Insert
    void insert(Course course);

    // Delete a specific course
    @Delete
    void delete(Course course);

    // Delete all courses (used for testing or reset)
    @Query("DELETE FROM courses")
    void deleteAllCourses();

    // Return all courses ordered by course code
    @Query("SELECT * FROM courses ORDER BY courseCode ASC")
    LiveData<List<Course>> getAllCourses();

    // Return a single course by its ID
    @Query("SELECT * FROM courses WHERE courseId = :courseId")
    LiveData<Course> getCourseById(int courseId);

    // Return all courses a given student is enrolled in
    @Query("SELECT c.* FROM courses c INNER JOIN CourseStudentCrossRef r ON c.courseId = r.courseId WHERE r.studentId = :studentId")
    LiveData<List<Course>> getCoursesForStudent(int studentId);

    //return courses synchronously
    @Query("SELECT * FROM courses")
    List<Course> getAllCoursesNow();

}
