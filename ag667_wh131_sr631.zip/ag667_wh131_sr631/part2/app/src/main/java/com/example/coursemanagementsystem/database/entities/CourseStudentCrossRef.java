package com.example.coursemanagementsystem.database.entities;

import androidx.room.Entity;

/**
 * Represents a many-to-many relationship between courses and students.
 * Each instance links a student to a course.
 */
@Entity(primaryKeys = {"courseId", "studentId"})
public class CourseStudentCrossRef {

    // Fields

    // ID of the course
    private int courseId;

    // ID of the student
    private int studentId;

    // Constructor
    public CourseStudentCrossRef(int courseId, int studentId) {
        this.courseId = courseId;
        this.studentId = studentId;
    }

    // Getters and Setters

    // courseId
    public int getCourseId() { return courseId; }
    public void setCourseId(int courseId) { this.courseId = courseId; }

    // studentId
    public int getStudentId() { return studentId; }
    public void setStudentId(int studentId) { this.studentId = studentId; }
}
