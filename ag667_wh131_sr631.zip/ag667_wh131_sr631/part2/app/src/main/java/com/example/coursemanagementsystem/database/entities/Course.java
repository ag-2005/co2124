package com.example.coursemanagementsystem.database.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Represents a course entity in the database.
 * Each course has a unique ID, course code, name, and lecturer name.
 */
@Entity(tableName = "courses")
public class Course {

    //Fields

    // Primary key for the course, auto-generated
    @PrimaryKey(autoGenerate = true)
    private int courseId;

    // Course code (e.g., CO2124)
    private String courseCode;

    // Course title (e.g., Data Analytics)
    private String courseName;

    // Lecturer delivering the course
    private String lecturerName;

    // Constructor
    public Course(String courseCode, String courseName, String lecturerName) {
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.lecturerName = lecturerName;
    }

    // Getters and Setters

    //courseId
    public int getCourseId() {return courseId;}
    public void setCourseId(int courseId) {this.courseId = courseId;}

    // courseCode
    public String getCourseCode() {return courseCode;}
    public void setCourseCode(String courseCode) {this.courseCode = courseCode;}

    //courseName
    public String getCourseName() {return courseName;}
    public void setCourseName(String courseName) {this.courseName = courseName;}

    //lecturerName
    public String getLecturerName() {return lecturerName;}
    public void setLecturerName(String lecturerName) {this.lecturerName = lecturerName;}
}
