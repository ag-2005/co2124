package com.example.coursemanagementsystem.adapters;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.coursemanagementsystem.R;
import com.example.coursemanagementsystem.database.entities.Student;

import java.util.ArrayList;
import java.util.List;

/**
 * RecyclerView Adapter for displaying a list of students enrolled in a course.
 * Supports click and long-click listeners for interaction, and binds student details
 * (name, email, and metric number) to each list item.
 * Used in CourseDetailsActivity to manage enrolled student views.
 */
public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.StudentViewHolder> {

    private List<Student> students = new ArrayList<>();
    private OnItemClickListener clickListener;
    private OnItemLongClickListener longClickListener;

    // Listener for short item clicks
    public interface OnItemClickListener {
        void onItemClick(Student student);
    }

    // Listener for long item presses
    public interface OnItemLongClickListener {
        void onItemLongClick(Student student);
    }

    // Set click listener
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.clickListener = listener;
    }

    // Set long click listener
    public void setOnItemLongClickListener(OnItemLongClickListener listener) {
        this.longClickListener = listener;
    }

    // ViewHolder for student item layout
    public static class StudentViewHolder extends RecyclerView.ViewHolder {
        public TextView nameTextView;
        public TextView emailTextView;
        public TextView usernameTextView;

        public StudentViewHolder(@NonNull View itemView, OnItemClickListener clickListener, OnItemLongClickListener longClickListener, List<Student> students) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.studentNameTextView);
            emailTextView = itemView.findViewById(R.id.studentEmailTextView);
            usernameTextView = itemView.findViewById(R.id.studentUsernameTextView);

            // Handle short tap
            itemView.setOnClickListener(v -> {
                int position = getBindingAdapterPosition();
                if (clickListener != null && position != RecyclerView.NO_POSITION) {
                    clickListener.onItemClick(students.get(position));
                }
            });

            // Handle long press
            itemView.setOnLongClickListener(v -> {
                int position = getBindingAdapterPosition();
                if (longClickListener != null && position != RecyclerView.NO_POSITION) {
                    longClickListener.onItemLongClick(students.get(position));
                    return true;
                }
                return false;
            });
        }
    }

    // Default constructor
    public StudentAdapter() {}

    // Inflate item layout and return ViewHolder
    @NonNull
    @Override
    public StudentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.student_item, parent, false);
        return new StudentViewHolder(view, clickListener, longClickListener, students);
    }

    // Bind student data to the ViewHolder
    @Override
    public void onBindViewHolder(@NonNull StudentViewHolder holder, int position) {
        Student currentStudent = students.get(position);
        holder.nameTextView.setText(currentStudent.getName());
        holder.emailTextView.setText(currentStudent.getEmail());
        holder.usernameTextView.setText(currentStudent.getUserName());
    }

    // Return total number of students
    @Override
    public int getItemCount() {
        return students.size();
    }

    // Update the student list and refresh the view
    @SuppressLint("NotifyDataSetChanged")
    public void setStudents(List<Student> students) {
        this.students = students;
        notifyDataSetChanged();
    }
}
