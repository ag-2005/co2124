package com.example.coursemanagementsystem.viewmodels;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.coursemanagementsystem.database.entities.Course;
import com.example.coursemanagementsystem.repositories.CourseRepository;

import java.util.List;

/**
 * ViewModel for managing UI-related data for courses.
 * Communicates with the CourseRepository to access and manipulate course data.
 */
public class CourseViewModel extends AndroidViewModel {

    private final CourseRepository repository;
    private final LiveData<List<Course>> allCourses;

    //Initialize the ViewModel and load all courses from the repository.
    public CourseViewModel(Application application) {
        super(application);
        repository = new CourseRepository(application);
        allCourses = repository.getAllCourses();
    }

    //Return LiveData containing a list of all courses.
    public LiveData<List<Course>> getAllCourses() {
        return allCourses;
    }

    //Insert a new course via the repository.
    public void insert(Course course) {
        repository.insert(course);
    }

    //Delete a course via the repository.
    public void delete(Course course) {
        repository.delete(course);
    }
}
