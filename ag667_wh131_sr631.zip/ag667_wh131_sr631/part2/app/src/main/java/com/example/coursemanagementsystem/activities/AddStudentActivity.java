package com.example.coursemanagementsystem.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.coursemanagementsystem.R;
import com.example.coursemanagementsystem.database.AppDatabase;
import com.example.coursemanagementsystem.database.entities.CourseStudentCrossRef;
import com.example.coursemanagementsystem.database.entities.Student;
import com.google.android.material.textfield.TextInputEditText;

import java.util.List;

/**
 * Activity for adding a new student to a specific course.
 * Performs input validation, ensures student uniqueness by email and matric,
 * creates the student if needed, and links them to the selected course.
 * Prevents duplicate enrollments and gives clear error feedback.
 */
public class AddStudentActivity extends AppCompatActivity {

    private TextInputEditText nameEditText, emailEditText, userNameEditText;
    private AppDatabase db;
    private int courseId;

    // Capitalizes each word (e.g., "john smith" → "John Smith")
    private String capitalizeEachWord(String input) {
        String[] words = input.trim().split("\\s+");
        StringBuilder capitalized = new StringBuilder();

        for (String word : words) {
            if (word.length() > 0) {
                capitalized.append(Character.toUpperCase(word.charAt(0)))
                        .append(word.substring(1)).append(" ");
            }
        }

        return capitalized.toString().trim();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Show back button in the top action bar and set screen title
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Add Student");
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_student);

        // Initialize UI components
        nameEditText = findViewById(R.id.studentNameEditText);
        emailEditText = findViewById(R.id.studentEmailEditText);
        userNameEditText = findViewById(R.id.studentUsernameEditText);
        Button addButton = findViewById(R.id.addStudentButton);

        // Get database instance and course ID passed from previous screen
        db = AppDatabase.getInstance(getApplicationContext());
        courseId = getIntent().getIntExtra(CourseDetailsActivity.EXTRA_COURSE_ID, -1);

        // Handle Add button click
        addButton.setOnClickListener(v -> addStudent());
    }

    // Handle toolbar back button click
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    // Adds a student to the database and links them to the course
    private void addStudent() {
        // Fetch user input
        String rawName = nameEditText.getText().toString().trim();
        String name = capitalizeEachWord(rawName.toLowerCase());

        String email = emailEditText.getText().toString().trim();
        String rawUsername = userNameEditText.getText().toString().trim(); // Preserve case for display
        String username = rawUsername.toLowerCase(); // Save lowercase for uniqueness

        // Check for empty fields
        if (name.isEmpty() || email.isEmpty() || rawUsername.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate full name (must contain first and last name, no hyphens)
        if (!name.matches("^[A-Za-z]+\\s+[A-Za-z]+$")) {
            Toast.makeText(this, "Please use student's full name", Toast.LENGTH_LONG).show();
            return;
        }

        // Validate email format and known TLDs
        if (!email.matches("^[\\w.-]+@[A-Za-z0-9.-]+\\.(com|org|net|gov|edu|uk|co\\.uk|ac\\.uk|io|info|dev|ai|[a-z]{2})$")) {
            Toast.makeText(this, "Invalid email format", Toast.LENGTH_LONG).show();
            return;
        }

        // Validate username (matric number) format: 2 letters + 1–3 digits
        //if (!username.matches("^[a-zA-Z]{2}\\d{1,3}$")) {
        //Toast.makeText(this, "Username must be 2 letters followed by up to 3 numbers", Toast.LENGTH_LONG).show();
        //return;
        //}

        // Perform DB operations in background thread
        AppDatabase.databaseWriteExecutor.execute(() -> {
            Student existingByMatric = db.studentDao().findStudentByUsername(username);
            Student existingByEmail = db.studentDao().findStudentByEmail(email);
            int studentId;

            if (existingByMatric != null) {
                studentId = existingByMatric.getStudentId();

                // Check if this student is already enrolled in this course
                boolean alreadyEnrolled = db.courseStudentCrossRefDao().isStudentEnrolled(courseId, studentId) > 0;
                if (alreadyEnrolled) {
                    runOnUiThread(() -> Toast.makeText(this, "Student already enrolled.", Toast.LENGTH_SHORT).show());
                    return;
                }

                // Add enrollment link
                db.courseStudentCrossRefDao().insert(new CourseStudentCrossRef(courseId, studentId));
                runOnUiThread(() -> {
                    Toast.makeText(this, "Student added", Toast.LENGTH_SHORT).show();
                    finish();
                });
                return;

            } else if (existingByEmail != null) {
                runOnUiThread(() -> Toast.makeText(this, "Email already in use by a different student.", Toast.LENGTH_LONG).show());
                return;
            }

            // Create new student (name capitalized, username lowercase)
            Student newStudent = new Student(name, email, username);
            db.studentDao().insert(newStudent);
            studentId = db.studentDao().getStudentByUsername(username).getStudentId();

            // Link student to course
            db.courseStudentCrossRefDao().insert(new CourseStudentCrossRef(courseId, studentId));
            runOnUiThread(() -> {
                Toast.makeText(this, "Student added", Toast.LENGTH_SHORT).show();
                finish();
            });
        });
    }
}
