package com.example.coursemanagementsystem.adapters;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.coursemanagementsystem.R;
import com.example.coursemanagementsystem.database.entities.Course;

import java.util.List;

/**
 * RecyclerView Adapter for displaying a list of courses.
 * Binds course information (code, name, lecturer) to each list item,
 * and supports both click and long-press interactions for navigating to
 * details or performing actions such as deletion.
 * Used primarily in MainActivity to render course items.
 */
public class CourseAdapter extends RecyclerView.Adapter<CourseAdapter.CourseViewHolder> {

    private List<Course> courses;
    private OnItemClickListener clickListener;
    private OnItemLongClickListener longClickListener;

    // Interface for handling single tap events
    public interface OnItemClickListener {
        void onItemClick(Course course);
    }

    // Interface for handling long press events
    public interface OnItemLongClickListener {
        void onItemLongClick(Course course);
    }

    // Set the click listener for item taps
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.clickListener = listener;
    }

    // Set the long click listener for item holds
    public void setOnItemLongClickListener(OnItemLongClickListener listener) {
        this.longClickListener = listener;
    }

    // ViewHolder class representing each course item in the RecyclerView
    public static class CourseViewHolder extends RecyclerView.ViewHolder {
        public TextView courseCodeTextView;
        public TextView courseNameTextView;
        public TextView lecturerNameTextView;

        public CourseViewHolder(View itemView, OnItemClickListener clickListener, OnItemLongClickListener longClickListener, List<Course> courses) {
            super(itemView);
            courseCodeTextView = itemView.findViewById(R.id.courseCodeTextView);
            courseNameTextView = itemView.findViewById(R.id.courseNameTextView);
            lecturerNameTextView = itemView.findViewById(R.id.lecturerNameTextView);

            // Handle item tap
            itemView.setOnClickListener(v -> {
                int position = getBindingAdapterPosition();
                if (clickListener != null && position != RecyclerView.NO_POSITION) {
                    clickListener.onItemClick(courses.get(position));
                }
            });

            // Handle item long press
            itemView.setOnLongClickListener(v -> {
                int position = getBindingAdapterPosition();
                if (longClickListener != null && position != RecyclerView.NO_POSITION) {
                    longClickListener.onItemLongClick(courses.get(position));
                    return true;
                }
                return false;
            });
        }
    }

    // Adapter constructor
    public CourseAdapter(List<Course> courses) {
        this.courses = courses;
    }

    // Inflate the layout and return a new ViewHolder
    @NonNull
    @Override
    public CourseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.course_item, parent, false);
        return new CourseViewHolder(view, clickListener, longClickListener, courses);
    }

    // Bind course data to views for each item
    @Override
    public void onBindViewHolder(@NonNull CourseViewHolder holder, int position) {
        Course currentCourse = courses.get(position);
        holder.courseCodeTextView.setText(currentCourse.getCourseCode());
        holder.courseNameTextView.setText(currentCourse.getCourseName());
        holder.lecturerNameTextView.setText(currentCourse.getLecturerName());
    }

    // Return total number of course items
    @Override
    public int getItemCount() {
        return courses.size();
    }

    // Update the course list and refresh the RecyclerView
    @SuppressLint("NotifyDataSetChanged")
    public void setCourses(List<Course> courses) {
        this.courses = courses;
        notifyDataSetChanged();
    }
}
