package com.example.coursemanagementsystem.database.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Represents a student entity in the database.
 * Each student has a unique ID, full name, email, and a matriculation number (username).
 */
@Entity(tableName = "students")
public class Student {

    // Fields

    // Primary key for the student, auto-generated
    @PrimaryKey(autoGenerate = true)
    private int studentId;

    // Full name of the student
    private String name;

    // Email address of the student
    private String email;

    // Matriculation number / unique username (e.g., wh131)
    private String userName;

    // Constructor
    public Student(String name, String email, String userName) {
        this.name = name;
        this.email = email;
        this.userName = userName;
    }

    // Getters and Setters

    // studentId
    public int getStudentId() { return studentId; }
    public void setStudentId(int studentId) { this.studentId = studentId; }

    // name
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    // email
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    // userName (metric number)
    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }
}
