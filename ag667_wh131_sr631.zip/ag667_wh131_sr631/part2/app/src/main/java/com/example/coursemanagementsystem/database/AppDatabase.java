package com.example.coursemanagementsystem.database;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.coursemanagementsystem.database.daos.CourseDao;
import com.example.coursemanagementsystem.database.daos.CourseStudentCrossRefDao;
import com.example.coursemanagementsystem.database.daos.StudentDao;
import com.example.coursemanagementsystem.database.entities.Course;
import com.example.coursemanagementsystem.database.entities.CourseStudentCrossRef;
import com.example.coursemanagementsystem.database.entities.Student;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Main Room database for the Course Management System.
 * Includes DAOs for courses, students, and course-student relationships.
 */
@Database(entities = {Course.class, Student.class, CourseStudentCrossRef.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    // Singleton instance of the database
    private static AppDatabase INSTANCE;

    // Thread pool executor for background database operations
    public static final ExecutorService databaseWriteExecutor = Executors.newFixedThreadPool(4);

    // DAOs exposed to the rest of the app
    public abstract CourseDao courseDao();
    public abstract StudentDao studentDao();
    public abstract CourseStudentCrossRefDao courseStudentCrossRefDao();

    /**
     * Returns the singleton instance of the AppDatabase.
     * If not initialized, creates the database instance.
     */
    public static synchronized AppDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            AppDatabase.class, "course_management_db")
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return INSTANCE;
    }
}
