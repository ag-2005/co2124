package com.example.coursemanagementsystem.repositories;

import android.app.Application;
import androidx.lifecycle.LiveData;

import com.example.coursemanagementsystem.database.AppDatabase;
import com.example.coursemanagementsystem.database.daos.StudentDao;
import com.example.coursemanagementsystem.database.entities.Course;
import com.example.coursemanagementsystem.database.entities.Student;

import java.util.List;

/**
 * Repository class that manages data operations related to students.
 * Acts as a mediator between the ViewModel and Room database layer.
 */
public class StudentRepository {

    private final Application application;
    private final StudentDao studentDao;
    private final LiveData<List<Student>> allStudents;

    //Initialize the DAO and LiveData instance for all students.
    public StudentRepository(Application application) {
        this.application = application;
        AppDatabase db = AppDatabase.getInstance(application);
        studentDao = db.studentDao();
        allStudents = studentDao.getAllStudents();
    }

    //Return an observable list of all students.
    public LiveData<List<Student>> getAllStudents() {
        return allStudents;
    }

    //Insert a student asynchronously
    public void insert(Student student) {
        AppDatabase.databaseWriteExecutor.execute(() -> {
            studentDao.insert(student);
        });
    }

    // Delete a student asynchronously
    public void delete(Student student) {
        AppDatabase.databaseWriteExecutor.execute(() -> {
            studentDao.delete(student);
        });
    }

    //Retrieve all students enrolled in a specific course
    public LiveData<List<Student>> getStudentsByCourseId(int courseId) {
        return studentDao.getStudentsByCourseId(courseId);
    }

    //Retrieve all courses a student is enrolled in
    public LiveData<List<Course>> getCoursesForStudent(int studentId) {
        return AppDatabase.getInstance(application).courseDao().getCoursesForStudent(studentId);
    }

    //Retrieve a student by their unique ID
    public LiveData<Student> getStudentById(int studentId) {
        return studentDao.getStudentById(studentId);
    }
}
