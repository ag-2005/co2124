package com.example.coursemanagementsystem.activities;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.coursemanagementsystem.R;
import com.example.coursemanagementsystem.adapters.StudentAdapter;
import com.example.coursemanagementsystem.database.AppDatabase;
import com.example.coursemanagementsystem.viewmodels.StudentViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

/**
 * Displays detailed information about a specific course,
 * including its code, name, lecturer, and the list of enrolled students.
 * Provides functionality to:
 * - Navigate to individual student details
 * - Add a new student to the course
 * - Remove a student (and delete if no longer enrolled in other courses)
 */
public class CourseDetailsActivity extends AppCompatActivity {

    // Keys for passing course data via intent
    public static final String EXTRA_COURSE_ID = "courseId";
    public static final String EXTRA_COURSE_NAME = "courseName";
    public static final String EXTRA_COURSE_CODE = "courseCode";
    public static final String EXTRA_LECTURER_NAME = "lecturerName";

    private StudentAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_details);

        // Show back button in the top action bar and set screen title
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Course Details");
        }

        // Get course data passed from previous screen
        int courseId = getIntent().getIntExtra(EXTRA_COURSE_ID, -1);
        String courseCode = getIntent().getStringExtra(EXTRA_COURSE_CODE);
        String courseName = getIntent().getStringExtra(EXTRA_COURSE_NAME);
        String lecturerName = getIntent().getStringExtra(EXTRA_LECTURER_NAME);

        // Populate course info into text views
        TextView codeText = findViewById(R.id.courseCodeTextView);
        TextView nameText = findViewById(R.id.courseNameTextView);
        TextView lecturerText = findViewById(R.id.lecturerNameTextView);
        codeText.setText(courseCode);
        nameText.setText(courseName);
        lecturerText.setText(lecturerName);

        // Setup RecyclerView for listing enrolled students
        RecyclerView studentsRecyclerView = findViewById(R.id.studentsRecyclerView);
        adapter = new StudentAdapter();
        studentsRecyclerView.setAdapter(adapter);
        studentsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // ViewModel to fetch enrolled students
        StudentViewModel studentViewModel = new ViewModelProvider(this).get(StudentViewModel.class);

        // Observe students for this course and show message if none are enrolled
        TextView emptyStudentsMessage = findViewById(R.id.emptyStudentsMessage);
        studentViewModel.getStudentsByCourseId(courseId).observe(this, students -> {
            adapter.setStudents(students);

            // Show/hide empty message
            if (students.isEmpty()) {
                emptyStudentsMessage.setVisibility(View.VISIBLE);
            } else {
                emptyStudentsMessage.setVisibility(View.GONE);
            }
        });

        // Handle short click to open student details
        adapter.setOnItemClickListener(student -> {
            Intent intent = new Intent(CourseDetailsActivity.this, StudentDetailsActivity.class);
            intent.putExtra(StudentDetailsActivity.EXTRA_STUDENT_ID, student.getStudentId());
            startActivity(intent);
        });

// Handle long press to open dialog with Edit / Remove
        adapter.setOnItemLongClickListener(student -> {
            new AlertDialog.Builder(this)
                    .setTitle("Student Options")
                    .setItems(new CharSequence[]{"Edit", "Remove"}, (dialog, which) -> {
                        if (which == 0) {
                            // EDIT
                            Intent intent = new Intent(this, EditStudentActivity.class);
                            intent.putExtra(EditStudentActivity.EXTRA_STUDENT_ID, student.getStudentId());
                            intent.putExtra(EXTRA_COURSE_ID, courseId);
                            startActivity(intent);
                        } else if (which == 1) {
                            // REMOVE
                            new AlertDialog.Builder(this)
                                    .setTitle("Remove Student")
                                    .setMessage("Remove this student from the course?\nThey will be deleted if not enrolled in any other courses.")
                                    .setPositiveButton("Delete", (d, w) -> {
                                        AppDatabase.databaseWriteExecutor.execute(() -> {
                                            AppDatabase db = AppDatabase.getInstance(this);

                                            db.courseStudentCrossRefDao().deleteStudentFromCourse(courseId, student.getStudentId());

                                            boolean isOrphan = db.courseStudentCrossRefDao()
                                                    .getCoursesForStudent(student.getStudentId())
                                                    .isEmpty();

                                            if (isOrphan) {
                                                db.studentDao().deleteById(student.getStudentId());
                                            }
                                        });
                                    })
                                    .setNegativeButton("Cancel", null)
                                    .show();
                        }
                    })
                    .show();
        });


        // Handle FAB press to add a new student to the course
        FloatingActionButton addStudentFab = findViewById(R.id.addStudentFab);
        addStudentFab.setOnClickListener(v -> {
            Intent intent = new Intent(CourseDetailsActivity.this, AddStudentActivity.class);
            intent.putExtra(EXTRA_COURSE_ID, courseId);
            startActivity(intent);
        });

    }

    // Handle back arrow press in the action bar
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish(); // Go back to previous activity
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
